
# Grade Calculator

A simple Java program to calculate the average, percentage, and grade based on marks entered for five subjects.

## Features
- Enter marks for five subjects (Maths, Physics, Chemistry, English, and Telugu).
- Calculate:
  - **Average**
  - **Percentage**
  - **Grade** (Based on the total marks).

## Technologies Used
- **Java**: Core programming language.

## Usage
1. Compile the program using:
   ```
   javac Marks.java
   ```
2. Run the program using:
   ```
   java Marks
   ```

## Sample Output
```
=== Welcome to Grade Calculator ===
Note: Total marks for each subject = 100 (Total = 500)
Enter your Maths marks (0-100): 90
Enter your Physics marks (0-100): 85
Enter your Chemistry marks (0-100): 80
Enter your English marks (0-100): 75
Enter your Telugu marks (0-100): 88

Select an option:
1) Average
2) Percentage
3) Grade
4) Exit
2
Percentage: 83.6%
```

## Learning Outcomes
- Gained experience in validating user input for constraints.
- Practiced modular programming by dividing logic into reusable methods.
- Improved understanding of conditional logic for grade calculation.
