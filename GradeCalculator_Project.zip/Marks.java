
import java.util.Scanner;

public class Marks {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("=== Welcome to Grade Calculator ===");
        System.out.println("Note: Total marks for each subject = 100 (Total = 500)");

        double math = getMarks(input, "Maths");
        double phy = getMarks(input, "Physics");
        double che = getMarks(input, "Chemistry");
        double eng = getMarks(input, "English");
        double tel = getMarks(input, "Telugu");

        boolean isRunning = true;
        while (isRunning) {
            System.out.println("\nSelect an option:");
            System.out.println("1) Average");
            System.out.println("2) Percentage");
            System.out.println("3) Grade");
            System.out.println("4) Exit");

            char select = input.next().charAt(0);
            switch (select) {
                case '1':
                    System.out.println("Average: " + average(math, phy, che, eng, tel));
                    break;
                case '2':
                    System.out.println("Percentage: " + calculatePercentage(math, phy, che, eng, tel) + "%");
                    break;
                case '3':
                    System.out.println("Grade: " + calculateGrade(math, phy, che, eng, tel));
                    break;
                case '4':
                    System.out.println("Exiting program...");
                    isRunning = false;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    public static double getMarks(Scanner input, String subject) {
        double marks;
        do {
            System.out.print("Enter your " + subject + " marks (0-100): ");
            marks = input.nextDouble();
            if (marks < 0 || marks > 100) {
                System.out.println("Invalid marks. Please enter a value between 0 and 100.");
            }
        } while (marks < 0 || marks > 100);
        return marks;
    }

    public static double average(double m, double p, double c, double e, double t) {
        return (m + p + c + e + t) / 5;
    }

    public static double calculatePercentage(double m, double p, double c, double e, double t) {
        return ((m + p + c + e + t) / 500) * 100;
    }

    public static String calculateGrade(double m, double p, double c, double e, double t) {
        double total = m + p + c + e + t;
        if (total > 450) {
            return "A";
        } else if (total > 380) {
            return "B";
        } else if (total > 300) {
            return "C";
        } else if (total > 250) {
            return "D";
        } else {
            return "F";
        }
    }
}
